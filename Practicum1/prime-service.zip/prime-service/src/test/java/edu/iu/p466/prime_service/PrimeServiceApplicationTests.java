package edu.iu.p466.prime_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrimeServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
